-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Temps de generació: 28-08-2023 a les 22:53:10
-- Versió del servidor: 10.1.21-MariaDB
-- Versió de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `buscadores_cercadors`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `disciplinas_buscador`
--

CREATE TABLE `disciplinas_buscador` (
  `id` tinyint(3) NOT NULL,
  `disciplina` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `disciplinas_buscador`
--

INSERT INTO `disciplinas_buscador` (`id`, `disciplina`) VALUES
(1, 'Artes Gráficas'),
(2, 'Manualidades'),
(3, 'Web'),
(4, 'Pintura'),
(5, 'Dibujo'),
(6, 'Juegos PC/');

--
-- Indexos per taules bolcades
--

--
-- Index de la taula `disciplinas_buscador`
--
ALTER TABLE `disciplinas_buscador`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `disciplinas_buscador`
--
ALTER TABLE `disciplinas_buscador`
  MODIFY `id` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
