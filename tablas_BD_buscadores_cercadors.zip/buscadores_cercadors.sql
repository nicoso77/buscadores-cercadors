-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Temps de generació: 28-08-2023 a les 22:49:59
-- Versió del servidor: 10.1.21-MariaDB
-- Versió de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `buscadores_cercadors`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `disciplinasimgs_buscador`
--

CREATE TABLE `disciplinasimgs_buscador` (
  `id` int(11) NOT NULL,
  `id_imatge` int(11) DEFAULT NULL,
  `disciplina` tinyint(2) NOT NULL,
  `visible` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `disciplinasimgs_buscador`
--

INSERT INTO `disciplinasimgs_buscador` (`id`, `id_imatge`, `disciplina`, `visible`) VALUES
(1, 0, 1, b'1'),
(2, 1, 5, b'1'),
(3, 2, 1, b'1'),
(4, 3, 1, b'1'),
(5, 4, 1, b'1'),
(6, 5, 4, b'1'),
(7, 6, 2, b'1'),
(8, 7, 2, b'1'),
(9, 8, 2, b'1'),
(10, 9, 2, b'1'),
(11, 10, 2, b'1'),
(12, 11, 6, b'1'),
(13, 12, 6, b'1'),
(14, 13, 6, b'1');

-- --------------------------------------------------------

--
-- Estructura de la taula `disciplinas_buscador`
--

CREATE TABLE `disciplinas_buscador` (
  `id` tinyint(3) NOT NULL,
  `disciplina` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `disciplinas_buscador`
--

INSERT INTO `disciplinas_buscador` (`id`, `disciplina`) VALUES
(1, 'Artes Gráficas'),
(2, 'Manualidades'),
(3, 'Web'),
(4, 'Pintura'),
(5, 'Dibujo'),
(6, 'Juegos PC/');

-- --------------------------------------------------------

--
-- Estructura de la taula `imgs_buscador`
--

CREATE TABLE `imgs_buscador` (
  `id` int(11) NOT NULL,
  `ordre` int(4) NOT NULL,
  `class` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `href` varchar(500) COLLATE utf8_bin NOT NULL,
  `img` varchar(100) COLLATE utf8_bin NOT NULL,
  `alt` varchar(400) COLLATE utf8_bin NOT NULL,
  `visible` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `imgs_buscador`
--

INSERT INTO `imgs_buscador` (`id`, `ordre`, `class`, `href`, `img`, `alt`, `visible`) VALUES
(0, 0, 'horizontal', '140609-samarreta-cor-arciris-01.jpg', '140609-samarreta-cor-arciris-01.jpg', 'Disseny d\'estampació per a samarreta; merchandising de \"Proyecto Glass\".', 1),
(1, 1, 'vertical', '140916-Dibuix-Gat-01.jpg', '140916-Dibuix-Gat-01.jpg', 'Dibujo de gato a lapiz sob papel, a partir de una fotografía. Dibuix de gat a llapis sobre paper, a partir d\'una fotografia.', 1),
(2, 2, 'vertical', '150404-Cartell-Sinver-cicle-cinema-LGBT.jpg', '150404-Cartell-Sinver-cicle-cinema-LGBT.jpg', 'Cartell publicitari d\'un cicle de videofòrums, per a l\'associació universitària <a href=\"www.sinver.org\" class=\"fontRed\" target=\"_blank\">Sin Vergüenza</a>.', 1),
(3, 3, 'horizontal', '151130-Banner-bolos-lgtbfobia-SinVer-color-01.jpg', '151130-Banner-bolos-lgtbfobia-SinVer-color-01.jpg', '', 1),
(4, 4, 'vertical', '160205-Cartell-Sinver-Paragraf-175-03.jpg', '160205-Cartell-Sinver-Paragraf-175-03.jpg', 'Cartell publicitari de l\'activitat \"Cinefòrum PARAGRAPH 175\", per a l\'associació universitaria Sin vergüenza (Illustrator).', 1),
(5, 5, 'horizontal', '151116-aquearella-Marina-primera-NSO-01.jpg', '151116-aquearella-Marina-primera-NSO-01.jpg', 'Aquarel·la.', 1),
(6, 6, 'horizontal', '150423-Elements-decoratius-simulen-vitralls-01.jpg', '150423-Elements-decoratius-simulen-vitralls-01.jpg', 'Elements decoratius realitzats amb cartolines (imitació d\'un vitrall).', 1),
(7, 7, 'horizontal', '160700-Arbre-de-cartolines-01.jpg', '160700-Arbre-de-cartolines-01.jpg', 'Decoració realitzada amb cartolines de colors', 1),
(8, 8, 'horizontal', '100102-baixells-cascara-nous-02.jpg', '100102-baixells-cascara-nous-02.jpg', 'Reproducció de dos vaixells medievals (una coca i una nau vikinga) amb closques de nou.', 1),
(9, 9, 'horizontal', '120920-castell-01.jpg', '120920-castell-01.jpg', 'Maqueta d\'un castell medieval imaginari, amb fossar, realitzat amb fang.', 1),
(10, 10, 'horizontal', '120920-castell-02.jpg', '120920-castell-02.jpg', 'Maqueta d\'un castell medieval imaginari, amb fossar, realitzat amb fang (visió frontal).', 1),
(11, 11, 'horizontal', '140108_vista-genreal-de-ciutat-medieval-realitzada-amb-joc-minecraft.jpg', '140108_vista-genreal-de-ciutat-medieval-realitzada-amb-joc-minecraft.jpg', 'Captura de pantalla del joc d\'ordinador \"Minecraft\", on apareix la recreació d\'una ciutat medieval.', 1),
(12, 12, 'horizontal', '140212_interior-catedral-realitzada-amb-joc-minecraft-visio-cenital-nau.jpg', '140212_interior-catedral-realitzada-amb-joc-minecraft-visio-cenital-nau.jpg', 'Captura de pantalla del joc d\'ordinador \"Minecraft\", on es mostra l\'interior d\'una catedral, recreada imitant una catedral gòtica. ', 1),
(13, 13, 'horizontal', '140212_interior-catedral-realitzada-amb-joc-minecraft.jpg', '140212_interior-catedral-realitzada-amb-joc-minecraft.jpg', 'Captura de pantalla del joc d\'ordinador \"Minecraft\", on es mostra l\'interior d\'una catedral, recreada imitant una catedral gòtica.', 1);

-- --------------------------------------------------------

--
-- Estructura de la taula `toolsimgs_buscador`
--

CREATE TABLE `toolsimgs_buscador` (
  `id` int(11) NOT NULL,
  `id_imatge` int(4) DEFAULT NULL,
  `tool` tinyint(2) NOT NULL,
  `visible` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `toolsimgs_buscador`
--

INSERT INTO `toolsimgs_buscador` (`id`, `id_imatge`, `tool`, `visible`) VALUES
(1, 0, 1, b'1'),
(2, 1, 4, b'1'),
(3, 2, 1, b'1'),
(4, 3, 1, b'1'),
(5, 4, 1, b'1'),
(6, 5, 6, b'1'),
(7, 6, 9, b'1'),
(8, 7, 9, b'1'),
(9, 8, 9, b'1'),
(10, 9, 7, b'1'),
(11, 10, 7, b'1'),
(12, 11, 5, b'1'),
(13, 12, 5, b'1'),
(14, 13, 5, b'1');

-- --------------------------------------------------------

--
-- Estructura de la taula `tools_buscador`
--

CREATE TABLE `tools_buscador` (
  `id` tinyint(3) NOT NULL,
  `tool` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `tools_buscador`
--

INSERT INTO `tools_buscador` (`id`, `tool`) VALUES
(1, 'Illustrator'),
(2, 'InDesign'),
(3, 'Photoshop'),
(4, 'Llapisos'),
(5, 'Minecrat'),
(6, 'Aquarel·la'),
(7, 'Barro'),
(9, 'Otros');

--
-- Indexos per taules bolcades
--

--
-- Index de la taula `disciplinasimgs_buscador`
--
ALTER TABLE `disciplinasimgs_buscador`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_imatge` (`id_imatge`);

--
-- Index de la taula `disciplinas_buscador`
--
ALTER TABLE `disciplinas_buscador`
  ADD PRIMARY KEY (`id`);

--
-- Index de la taula `imgs_buscador`
--
ALTER TABLE `imgs_buscador`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Index de la taula `toolsimgs_buscador`
--
ALTER TABLE `toolsimgs_buscador`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_imatge` (`id_imatge`);

--
-- Index de la taula `tools_buscador`
--
ALTER TABLE `tools_buscador`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `disciplinasimgs_buscador`
--
ALTER TABLE `disciplinasimgs_buscador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT per la taula `disciplinas_buscador`
--
ALTER TABLE `disciplinas_buscador`
  MODIFY `id` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT per la taula `imgs_buscador`
--
ALTER TABLE `imgs_buscador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT per la taula `toolsimgs_buscador`
--
ALTER TABLE `toolsimgs_buscador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT per la taula `tools_buscador`
--
ALTER TABLE `tools_buscador`
  MODIFY `id` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
