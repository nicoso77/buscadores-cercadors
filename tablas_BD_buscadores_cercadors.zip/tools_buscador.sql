-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Temps de generació: 28-08-2023 a les 22:53:30
-- Versió del servidor: 10.1.21-MariaDB
-- Versió de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `buscadores_cercadors`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `tools_buscador`
--

CREATE TABLE `tools_buscador` (
  `id` tinyint(3) NOT NULL,
  `tool` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `tools_buscador`
--

INSERT INTO `tools_buscador` (`id`, `tool`) VALUES
(1, 'Illustrator'),
(2, 'InDesign'),
(3, 'Photoshop'),
(4, 'Llapisos'),
(5, 'Minecrat'),
(6, 'Aquarel·la'),
(7, 'Barro'),
(9, 'Otros');

--
-- Indexos per taules bolcades
--

--
-- Index de la taula `tools_buscador`
--
ALTER TABLE `tools_buscador`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `tools_buscador`
--
ALTER TABLE `tools_buscador`
  MODIFY `id` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
