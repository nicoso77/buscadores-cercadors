-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Temps de generació: 28-08-2023 a les 22:53:24
-- Versió del servidor: 10.1.21-MariaDB
-- Versió de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `buscadores_cercadors`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `toolsimgs_buscador`
--

CREATE TABLE `toolsimgs_buscador` (
  `id` int(11) NOT NULL,
  `id_imatge` int(4) DEFAULT NULL,
  `tool` tinyint(2) NOT NULL,
  `visible` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Bolcant dades de la taula `toolsimgs_buscador`
--

INSERT INTO `toolsimgs_buscador` (`id`, `id_imatge`, `tool`, `visible`) VALUES
(1, 0, 1, b'1'),
(2, 1, 4, b'1'),
(3, 2, 1, b'1'),
(4, 3, 1, b'1'),
(5, 4, 1, b'1'),
(6, 5, 6, b'1'),
(7, 6, 9, b'1'),
(8, 7, 9, b'1'),
(9, 8, 9, b'1'),
(10, 9, 7, b'1'),
(11, 10, 7, b'1'),
(12, 11, 5, b'1'),
(13, 12, 5, b'1'),
(14, 13, 5, b'1');

--
-- Indexos per taules bolcades
--

--
-- Index de la taula `toolsimgs_buscador`
--
ALTER TABLE `toolsimgs_buscador`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_imatge` (`id_imatge`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `toolsimgs_buscador`
--
ALTER TABLE `toolsimgs_buscador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
